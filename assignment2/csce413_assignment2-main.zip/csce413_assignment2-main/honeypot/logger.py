"""Logging helpers for the honeypot."""


def create_logger():
    raise NotImplementedError("Implement logging setup for your honeypot")
